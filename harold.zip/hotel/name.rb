class Name
	attr_reader :name
	attr_writer :name

	def initialize(name)
		@name = name
	end

	def what_is_your_name
		"Name of guest #{@name}"
	end
end
