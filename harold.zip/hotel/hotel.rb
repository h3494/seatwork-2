require 'sinatra'

get '/' do
	erb :index		 
end

get '/rooms' do
	erb :rooms
end
	
get '/about' do
	erb :about
end
	
post '/reservations' do
	@name = Room.new params[:room]
	erb :reservations
end
