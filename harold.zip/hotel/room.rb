class Room 
	attr_reader :room
	attr_writer :room

	def initialize(room)
		@name = room
	end

	def what_room
		"The room you reserved is a #{@name}"
	end
end
